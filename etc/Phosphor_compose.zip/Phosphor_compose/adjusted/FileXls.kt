package com.machiav3lli.backup.ui.compose.icons.phosphor


import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType.Companion.NonZero
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap.Companion.Butt
import androidx.compose.ui.graphics.StrokeJoin.Companion.Miter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.ImageVector.Builder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.machiav3lli.backup.ui.compose.icons.Phosphor

val Phosphor.FileXls: ImageVector
    get() {
        if (_file_xls != null) {
            return _file_xls!!
        }
        _file_xls = Builder(
            name = "File-xls",
            defaultWidth = 24.0.dp,
            defaultHeight = 24.0.dp,
            viewportWidth = 256.0f,
            viewportHeight = 256.0f,
        ).apply {
            path(
                fill = SolidColor(Color(0xFF000000)), stroke = null, strokeLineWidth = 0.0f,
                strokeLineCap = Butt, strokeLineJoin = Miter, strokeLineMiter = 4.0f,
                pathFillType = NonZero
            ) {
                moveTo(156.0f, 216.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, -8.0f, 8.0f)
                lineTo(120.0f, 224.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, -8.0f, -8.0f)
                lineTo(112.0f, 168.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, 16.0f, 0.0f)
                verticalLineToRelative(40.0f)
                horizontalLineToRelative(20.0f)
                arcTo(8.0f, 8.0f, 0.0f, false, true, 156.0f, 216.0f)
                close()
                moveTo(92.8f, 161.6f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, -11.2f, 1.6f)
                lineTo(70.0f, 178.7f)
                lineTo(58.4f, 163.2f)
                arcToRelative(8.0f, 8.0f, 0.0f, true, false, -12.8f, 9.6f)
                lineTo(60.0f, 192.0f)
                lineTo(45.6f, 211.2f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, 1.6f, 11.2f)
                arcTo(7.7f, 7.7f, 0.0f, false, false, 52.0f, 224.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, 6.4f, -3.2f)
                lineTo(70.0f, 205.3f)
                lineToRelative(11.6f, 15.5f)
                arcTo(8.0f, 8.0f, 0.0f, false, false, 88.0f, 224.0f)
                arcToRelative(7.7f, 7.7f, 0.0f, false, false, 4.8f, -1.6f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, 1.6f, -11.2f)
                lineTo(80.0f, 192.0f)
                lineToRelative(14.4f, -19.2f)
                arcTo(8.0f, 8.0f, 0.0f, false, false, 92.8f, 161.6f)
                close()
                moveTo(216.0f, 88.2f)
                lineTo(216.0f, 128.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, -16.0f, 0.0f)
                lineTo(200.0f, 96.0f)
                lineTo(152.0f, 96.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, -8.0f, -8.0f)
                lineTo(144.0f, 40.0f)
                lineTo(56.0f, 40.0f)
                verticalLineToRelative(88.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, true, -16.0f, 0.0f)
                lineTo(40.0f, 40.0f)
                arcTo(16.0f, 16.0f, 0.0f, false, true, 56.0f, 24.0f)
                horizontalLineToRelative(96.0f)
                arcToRelative(8.1f, 8.1f, 0.0f, false, true, 5.7f, 2.3f)
                lineToRelative(55.9f, 56.0f)
                arcTo(7.8f, 7.8f, 0.0f, false, true, 216.0f, 88.0f)
                close()
                moveTo(160.0f, 80.0f)
                horizontalLineToRelative(28.7f)
                lineTo(160.0f, 51.3f)
                close()
                moveTo(193.7f, 183.8f)
                curveToRelative(-3.1f, -0.8f, -8.6f, -2.3f, -9.7f, -3.6f)
                lineTo(184.0f, 180.0f)
                curveToRelative(0.0f, -3.3f, 2.4f, -5.0f, 7.0f, -5.0f)
                arcToRelative(18.4f, 18.4f, 0.0f, false, true, 10.0f, 3.2f)
                horizontalLineToRelative(-0.1f)
                arcTo(8.3f, 8.3f, 0.0f, false, false, 206.0f, 180.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, 8.0f, -8.0f)
                arcToRelative(7.6f, 7.6f, 0.0f, false, false, -2.9f, -6.1f)
                horizontalLineToRelative(0.0f)
                arcTo(33.4f, 33.4f, 0.0f, false, false, 191.0f, 159.0f)
                curveToRelative(-13.5f, 0.0f, -23.0f, 8.6f, -23.0f, 21.0f)
                reflectiveCurveToRelative(13.0f, 17.0f, 21.6f, 19.3f)
                curveToRelative(3.4f, 0.9f, 7.0f, 1.8f, 9.2f, 3.1f)
                reflectiveCurveToRelative(1.2f, 1.0f, 1.2f, 1.6f)
                reflectiveCurveToRelative(0.0f, 5.0f, -9.0f, 5.0f)
                arcToRelative(18.4f, 18.4f, 0.0f, false, true, -10.0f, -3.2f)
                horizontalLineToRelative(0.1f)
                arcTo(8.3f, 8.3f, 0.0f, false, false, 176.0f, 204.0f)
                arcToRelative(8.0f, 8.0f, 0.0f, false, false, -8.0f, 8.0f)
                arcToRelative(7.6f, 7.6f, 0.0f, false, false, 2.9f, 6.1f)
                horizontalLineToRelative(0.0f)
                arcTo(33.4f, 33.4f, 0.0f, false, false, 191.0f, 225.0f)
                curveToRelative(15.6f, 0.0f, 25.0f, -7.9f, 25.0f, -21.0f)
                reflectiveCurveTo(202.0f, 186.0f, 193.7f, 183.8f)
                close()
            }
        }
            .build()
        return _file_xls!!
    }

private var _file_xls: ImageVector? = null



@Preview
@Composable
fun FileXlsPreview() {
    Image(
        Phosphor.FileXls,
        null
    )
}
